(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_recharts_es6_e41bb580._.js",
  "static/chunks/node_modules_5f70bcb0._.js",
  "static/chunks/src_components_56475fb1._.js"
],
    source: "dynamic"
});
